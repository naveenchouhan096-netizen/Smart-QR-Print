import { describe, it, expect } from "vitest";
import { currentAccess, daysLeft, accessUntil, upiLink } from "@/lib/subscription";

const now = new Date("2026-10-26T00:00:00Z");
const mk = (start: string, end: string, status = "active") => ({
  id: start, plan: "premium", status, starts_at: start, expires_at: end,
});

describe("subscription access", () => {
  it("locks access once the subscription has expired", () => {
    expect(currentAccess([mk("2026-09-01T00:00:00Z", "2026-10-01T00:00:00Z")], now)).toBeNull();
  });
  it("grants access while within the paid period", () => {
    expect(currentAccess([mk("2026-10-20T00:00:00Z", "2026-11-20T00:00:00Z")], now)).not.toBeNull();
  });
  it("cancelled subscriptions do not grant access", () => {
    expect(currentAccess([mk("2026-10-20T00:00:00Z", "2026-11-20T00:00:00Z", "cancelled")], now)).toBeNull();
  });
  it("14-day trial shows 14 days left on day one", () => {
    const until = accessUntil([mk("2026-10-26T00:00:00Z", "2026-11-09T00:00:00Z")], now);
    expect(daysLeft(until, now)).toBe(14);
  });
  it("UPI link carries ₹199 in INR", () => {
    const l = upiLink("shop@upi", "Shop", 199, "Premium");
    expect(l).toContain("am=199");
    expect(l).toContain("cu=INR");
    expect(l).toContain("pa=shop%40upi");
  });
});
